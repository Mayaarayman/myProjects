// let mobileBtn = document.querySelector('header nav .mobile-btn');
// let mobileNav = document.querySelector('header .mobile-nav');
// let bodyElement = document.getElementById('main-wrapper');
// mobileBtn.addEventListener('click', showMenu);

// function showMenu() {
//     mobileNav.classList.toggle('showNav');
//     let navWidth = mobileNav.offsetWidth;
//Aley Khaled Solution
// if (mobileNav.classList.contains('showNav')) {
//     bodyElement.style.marginRight = navWidth + 'px';
//     bodyElement.style.marginLeft = -navWidth + 'px';
// } else {
//     bodyElement.style.marginRight = 0 + 'px';
//     bodyElement.style.marginLeft = 0 + 'px';
// }
//AbdElRahman Solution
//     if (bodyElement.style.marginRight > (0 + 'px')) {
//         bodyElement.style.marginRight = 0 + 'px';
//         bodyElement.style.marginLeft = 0 + 'px';
//     } else {
//         bodyElement.style.marginRight = mobileNav.offsetWidth + 'px';
//         bodyElement.style.marginLeft = -mobileNav.offsetWidth + 'px';
//     }
// }

$(document).ready(function() {
    $('.mobile-btn').click(function() {
        $('.mobile-nav').toggleClass('showNav');
        if ($('.mobile-nav').hasClass('showNav')) {
            $('body').css({
                marginLeft: -($('.mobile-nav').outerWidth()) + 'px',
                marginRight: ($('.mobile-nav').outerWidth()) + 'px'
            });
            $('.menu-icon').addClass('activeIcon');
        } else {
            $('body').css({
                marginLeft: '0px',
                marginRight: '0px'
            });
            $('.menu-icon').removeClass('activeIcon');
        }
    });
});